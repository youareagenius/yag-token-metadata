# YAG Token Security Policy

## コントラクトの安全性
- SPL標準に準拠（Token Program ID: TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA）
- メタデータ更新権限（Update Authority）あり：3Tb3wCcnykBwz63z1eVUU377JdTCtG4VRzcQowzW3tWq
- Solana Lockを利用したロックアップ済み

## 対策内容
- トークンメタデータ公開（GitHub）
- オープンソース運営方針
- エアドロップ・スワップの自動化（コードをGitHubで順次公開予定）
- ログ付きトランザクション（Botログ機能を開発中）

## 監査について
- 現在は非監査トークン
- 将来的に独立系監査機関によるレビューを予定（2025年Q3）