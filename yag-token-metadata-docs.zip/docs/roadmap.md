# YAG Project Roadmap

## 2025 Q1
- ✅ YAGトークン発行（Solana）
- ✅ トークン配分設計、エアドロップ準備
- ✅ Pinksale形式の配布Bot開発開始

## 2025 Q2（現在）
- 🛠 CoinGecko・Birdeye申請
- 🚀 Telegram Mini App（診断Bot、売買Bot）リリース
- 🌐 Webサイト強化、信頼性ドキュメント公開
- 🪙 ステーキング機能プロトタイプ公開予定

## 2025 Q3
- 📈 DEX拡充（Raydium、Jupiter統合）
- 👨‍💻 セキュリティ監査の実施
- 🎮 エンタメ型NFTゲーム・報酬設計
- 🏦 上場審査準備（CEX向け）

## 2025 Q4〜
- 🌍 グローバル展開（翻訳対応・多言語Bot）
- 🧠 Genius DAO発足準備